Configuration CreateADPDC
{
    param (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [securestring]$AdminPass,

        [Parameter(Mandatory)]
        [string]$AdminUser
    )

    $AdminCreds = New-Object System.Management.Automation.PSCredential($AdminUser, $AdminPass)

    Import-DscResource -ModuleName ActiveDirectoryDsc

    Node localhost
    {
        WindowsFeature ADDSInstall {
            Name = "AD-Domain-Services"
            Ensure = "Present"
        }

        xADDomain FirstDC {
            DomainName = $DomainName
            DomainAdministratorCredential = $AdminCreds
            SafemodeAdministratorPassword = $AdminCreds
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
    }
}